# Change Log
==========

0.4.1 (16.06.2021)
------------------
- First Relase: stable version
- A new feature added: `menu` - show all arguments and their description.
- A new feature added: `more_info` - show details about arguments function.
- A new feature added: `markdown_name=False` - when `True`, display only a string with a file `file_name` inside `![SegmentLocal](file_name.file_format)` string. You can paste this string into markdown in for example: **Jupyter Notebook**. When executed, it will display the picture inside markown's cell.

